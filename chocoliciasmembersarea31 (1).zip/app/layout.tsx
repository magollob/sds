import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Chocolícias da Fabi - Painel VIP",
  description:
    "Área exclusiva para membros com e-books e cursos de confeitaria. Transforme sua paixão em negócio lucrativo com receitas exclusivas e técnicas profissionais.",
  keywords: "confeitaria, e-books, cursos, brigadeiros gourmet, bolos, doces, receitas, negócio lucrativo",
  authors: [{ name: "Chocolícias da Fabi" }],
  creator: "Chocolícias da Fabi",
  publisher: "Chocolícias da Fabi",
  openGraph: {
    title: "Chocolícias da Fabi - Painel VIP Exclusivo para Confeiteiras 2025",
    description:
      "Acesse e-books exclusivos, receitas secretas e técnicas profissionais de confeitaria. Transforme sua paixão em um negócio lucrativo!",
    url: "https://chocoliciasdafabi.com",
    siteName: "Chocolícias da Fabi",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Chocolícias da Fabi - Painel VIP Exclusivo para Confeiteiras 2025",
      },
    ],
    locale: "pt_BR",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Chocolícias da Fabi - Painel VIP",
    description: "Área exclusiva com e-books e cursos de confeitaria para transformar sua paixão em negócio lucrativo.",
    images: ["/og-image.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: {
    google: "your-google-verification-code",
  },
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <head>
        <link rel="icon" href="/chocolicias-logo-circular.png" />
        <link rel="apple-touch-icon" href="/chocolicias-logo-circular.png" />
        <meta name="theme-color" content="#fd7ab1" />
      </head>
      <body className={inter.className}>{children}</body>
    </html>
  )
}
