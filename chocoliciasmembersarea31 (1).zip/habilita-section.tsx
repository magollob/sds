"use client"

import { useState, useEffect } from "react"
import { Lock, Clock, Sparkles } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface LockedProduct {
  id: string
  title: string
  description: string
  image: string
}

const lockedProducts: LockedProduct[] = [
  {
    id: "1",
    title: "Como faturar até R$10.000 com confeitaria",
    description: "Descubra as estratégias e segredos para escalar seus ganhos na confeitaria.",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/comofaturar-7uQ5X9AzqITIXYHKKjCvvfYNWI2Fel.png",
  },
  {
    id: "2",
    title: "Bônus de Vídeo Aulas",
    description: "Aulas exclusivas para aprimorar suas técnicas e conhecimentos em confeitaria.",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/bonussupresa-ecsgBSchfcDPJJwoHlCXot2VZyHih8.png",
  },
]

export default function HabilitaSection() {
  const [timeLeft, setTimeLeft] = useState<string>("")
  const [isUnlocked, setIsUnlocked] = useState(false)

  useEffect(() => {
    const calculateTimeLeft = () => {
      const epoch = new Date("2025-01-01T00:00:00Z").getTime()
      const now = Date.now()
      const msIn7Days = 7 * 24 * 60 * 60 * 1000
      const msIn4Days = 4 * 24 * 60 * 60 * 1000

      const elapsedMsSinceEpoch = now - epoch
      const currentCycleNumber = Math.floor(elapsedMsSinceEpoch / msIn7Days)
      const currentCycleEndMs = epoch + (currentCycleNumber + 1) * msIn7Days
      const remainingMsInCurrentCycle = currentCycleEndMs - now

      let displayRemainingMs = 0

      if (remainingMsInCurrentCycle <= msIn4Days) {
        displayRemainingMs = currentCycleEndMs + msIn7Days - now
      } else {
        displayRemainingMs = remainingMsInCurrentCycle
      }

      if (displayRemainingMs <= 0) {
        setIsUnlocked(true)
        setTimeLeft("Disponível agora!")
        return
      }

      setIsUnlocked(false)

      const days = Math.floor(displayRemainingMs / (1000 * 60 * 60 * 24))
      const hours = Math.floor((displayRemainingMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      const minutes = Math.floor((displayRemainingMs % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((displayRemainingMs % (1000 * 60)) / 1000)

      setTimeLeft(
        `${days.toString().padStart(2, "0")}d ${hours.toString().padStart(2, "0")}h ${minutes.toString().padStart(2, "0")}m ${seconds.toString().padStart(2, "0")}s`,
      )
    }

    calculateTimeLeft()
    const timer = setInterval(calculateTimeLeft, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <div className="mb-8 sm:mb-12">
      <Card className="glass-card-strong rounded-2xl p-4 sm:p-6 shadow-xl border border-pink-200/50">
        <CardHeader className="text-center pb-3 sm:pb-4 px-2 sm:px-6">
          <CardTitle className="text-lg sm:text-xl font-bold text-[#2b2b2b] flex items-center justify-center space-x-2 mb-2 sm:mb-4">
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-[#fd7ab1]" />
            <span className="text-lg leading-9 tracking-normal sm:text-5xl">Próxima Liberação em:</span>
          </CardTitle>

          {/* Mobile Timer Layout */}
          <div className="sm:hidden">
            <div className="timer-display rounded-2xl p-4 mb-4">
              <div className="text-white font-bold text-lg leading-tight text-center">{timeLeft}</div>
            </div>
          </div>

          {/* Desktop Timer Layout */}
          <div className="hidden sm:block">
            <div className="timer-display rounded-3xl p-6 mb-6">
              <div className="text-white font-extrabold text-3xl md:text-4xl lg:text-5xl tracking-tight leading-none text-center">
                {timeLeft}
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent className="pt-2 sm:pt-4 px-2 sm:px-6">
          <h4 className="text-base sm:text-lg font-semibold text-[#2b2b2b] mb-3 sm:mb-4 text-center">
            Produtos Bloqueados Atualmente:
          </h4>
          <div className="flex gap-4 sm:gap-6 overflow-x-auto pb-4 scrollbar-hide">
            {lockedProducts.map((product) => (
              <div key={product.id} className="relative group flex-shrink-0 w-56 sm:w-64 rounded-xl shadow-md">
                <div className="aspect-[3/4] rounded-xl overflow-hidden">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center p-4 text-center rounded-xl">
                  <Lock className="w-6 h-6 sm:w-8 sm:h-8 text-white mb-2" />
                  <h5 className="text-white font-semibold text-sm sm:text-base mb-2 line-clamp-2">{product.title}</h5>
                  {!isUnlocked && (
                    <Badge className="bg-gray-700 text-white border-0 text-xs">
                      <Clock className="w-3 h-3 mr-1" />
                      Em breve
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
